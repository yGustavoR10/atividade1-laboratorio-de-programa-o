import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class Principal extends JFrame {

    private JPanel painelPrincipal;
    private JPanel painelInicial;
    private JPanel painelCadastro;

    public Principal() {
        initComponents();
    }

    private void initComponents() {
        setTitle("MENU, ITENS DE MENU, FONTES");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        criarMenu();
        criarPaineis();

        add(painelPrincipal, BorderLayout.CENTER);
        mostrarPainel(painelInicial);
    }

    private void criarMenu() {
        JMenuBar barra = new JMenuBar();

        JMenu menuArquivo = new JMenu("Arquivo");
        JMenuItem itemNovo = new JMenuItem("Novo");
        JMenuItem itemSair = new JMenuItem("Sair");

        itemNovo.addActionListener(e -> mostrarPainel(painelCadastro));
        itemSair.addActionListener(e -> System.exit(0));

        menuArquivo.add(itemNovo);
        menuArquivo.add(itemSair);

        JMenu menuRelatorio = new JMenu("Relatório");
        JMenuItem itemCliente = new JMenuItem("Cliente");
        JMenuItem itemFornecedor = new JMenuItem("Fornecedor");

        itemCliente.addActionListener(e ->
            JOptionPane.showMessageDialog(this, "Relatório de clientes")
        );
        itemFornecedor.addActionListener(e ->
            JOptionPane.showMessageDialog(this, "Relatório de fornecedores")
        );

        menuRelatorio.add(itemCliente);
        menuRelatorio.add(itemFornecedor);

        JMenu menuSobre = new JMenu("Sobre");
        JMenuItem itemInfo = new JMenuItem("Info");

        itemInfo.addActionListener(e ->
            JOptionPane.showMessageDialog(
                this,
                "Aplicativo desenvolvido por: SEU NOME",
                "Informações",
                JOptionPane.INFORMATION_MESSAGE
            )
        );

        menuSobre.add(itemInfo);

        barra.add(menuArquivo);
        barra.add(menuRelatorio);
        barra.add(menuSobre);
        setJMenuBar(barra);
    }

    private void criarPaineis() {
        painelPrincipal = new JPanel(new BorderLayout());

        painelInicial = new JPanel(new BorderLayout());
        painelInicial.setBackground(Color.YELLOW);

        JLabel titulo = new JLabel("CONTROLE DE CLIENTES", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 18));
        titulo.setForeground(new Color(0, 100, 0));
        titulo.setBorder(javax.swing.BorderFactory.createEmptyBorder(25, 0, 10, 0));

        JLabel logo = new JLabel(new ImageIcon(
            getClass().getResource("/logo_unifagoc.png")
        ));
        logo.setHorizontalAlignment(SwingConstants.CENTER);

        painelInicial.add(titulo, BorderLayout.NORTH);
        painelInicial.add(logo, BorderLayout.CENTER);

        painelCadastro = new JPanel(new BorderLayout(10, 10));
        painelCadastro.setBackground(Color.WHITE);
        painelCadastro.setBorder(javax.swing.BorderFactory.createEmptyBorder(50, 80, 50, 80));

        JLabel tituloCadastro = new JLabel("CADASTRO DE CLIENTE", SwingConstants.CENTER);
        tituloCadastro.setFont(new Font("Arial", Font.BOLD, 20));

        JPanel botoes = new JPanel();
        JButton btnSalvar = new JButton("Salvar");
        JButton btnCancelar = new JButton("Cancelar");

        btnSalvar.setFont(new Font("Arial", Font.BOLD, 14));
        btnCancelar.setFont(new Font("Arial", Font.PLAIN, 14));

        btnSalvar.addActionListener(e ->
            JOptionPane.showMessageDialog(this, "Cliente salvo com sucesso!")
        );

        btnCancelar.addActionListener(e -> mostrarPainel(painelInicial));

        botoes.add(btnSalvar);
        botoes.add(btnCancelar);

        painelCadastro.add(tituloCadastro, BorderLayout.NORTH);
        painelCadastro.add(botoes, BorderLayout.CENTER);
    }

    private void mostrarPainel(JPanel painel) {
        painelPrincipal.removeAll();
        painelPrincipal.add(painel, BorderLayout.CENTER);
        painelPrincipal.revalidate();
        painelPrincipal.repaint();
    }

    public static void main(String[] args) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info :
                    javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ex) {
            // Visual padrão.
        }

        java.awt.EventQueue.invokeLater(() -> new Principal().setVisible(true));
    }
}
